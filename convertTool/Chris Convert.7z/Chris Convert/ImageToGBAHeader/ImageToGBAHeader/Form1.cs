﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ImageToGBAHeader
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void buttonOpenPallet_Click(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog1 = new OpenFileDialog();

			DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
			if (result == DialogResult.OK) // Test result.
			{
				textPalletFile.Text = openFileDialog1.FileName;
				LoadPallet();
			}
		}


		void LoadPallet()
		{
			Bitmap bitPallet = new Bitmap(textPalletFile.Text);
			picboxPallet.Image = bitPallet;

			textPalletOut.Text =
				ColourToHex(bitPallet.GetPixel(0, 0)) + ", " +
				ColourToHex(bitPallet.GetPixel(1, 0)) + ", " +
				ColourToHex(bitPallet.GetPixel(2, 0)) + ", " +
				ColourToHex(bitPallet.GetPixel(3, 0));



		}

		string ColourToHex(Color col)
		{
			return ColorTranslator.ToHtml(col);
		}



	}



}
